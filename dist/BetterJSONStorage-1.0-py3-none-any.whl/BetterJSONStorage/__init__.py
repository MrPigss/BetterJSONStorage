from .BetterJSONStorage import BetterJSONStorage, testStorage

__all__ = ['BetterJSONStorage']
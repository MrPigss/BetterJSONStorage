from pathlib import Path
from BetterJSONStorage import BetterJSONStorage

p = Path('pytest/empty.db')

print(BetterJSONStorage)